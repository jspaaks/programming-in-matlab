function [angle_deg] = rad2deg( angle_rad )

angle_deg = (angle_rad*360) / (2*pi);